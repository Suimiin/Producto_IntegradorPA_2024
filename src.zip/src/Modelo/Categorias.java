package Modelo;

public class Categorias {
    int idCategoria;
    String nombreCategoria;


}
