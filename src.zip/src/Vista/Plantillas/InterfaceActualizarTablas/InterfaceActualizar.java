package Vista.Plantillas.InterfaceActualizarTablas;

public interface InterfaceActualizar {
    void actualizarTabla();
}