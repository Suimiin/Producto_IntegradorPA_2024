package Vista.Inventario;

import javax.swing.*;
import Controlador.Controlador;
import Vista.Interfaces.ActualizarTable;
import Vista.Plantillas.GenerarComponentes;
import java.awt.*;
import java.util.ArrayList;

public class PantallaCompras extends JPanel implements ActualizarTable {

    private static final String[] COLUMNAS = {"ID Compra", "Producto", "Fecha", "Proveedor", "Cantidad"};
    private JLabel searchLabelProveedor, searchLabelFecha;
    private JTextField campoBusquedaProveedor, campoBusquedaFecha;
    private JTable tablaCompras;
    private JButton botonBuscar, botonExportarJSON, botonExportarCSV, botonExportarXML;

    public PantallaCompras() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Margen general
        setOpaque(true);

        // Panel superior que contiene los campos de búsqueda y el botón "Buscar"
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setOpaque(false);

        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panelBusqueda.setOpaque(false);

        // Etiquetas y campos de búsqueda para proveedor y fecha
        searchLabelProveedor = new JLabel("Buscar por Proveedor:");
        campoBusquedaProveedor = GenerarComponentes.crearCampoTexto(20);

        searchLabelFecha = new JLabel("Buscar por Fecha:");
        campoBusquedaFecha = GenerarComponentes.crearCampoTexto(20);

        panelBusqueda.add(searchLabelProveedor);
        panelBusqueda.add(campoBusquedaProveedor);
        panelBusqueda.add(searchLabelFecha);
        panelBusqueda.add(campoBusquedaFecha);
        panelSuperior.add(panelBusqueda, BorderLayout.WEST);

        // Botón de búsqueda
        botonBuscar = GenerarComponentes.crearBoton("Buscar");
        JPanel panelBotonBuscar = GenerarComponentes.crearPanelFlowLayout(FlowLayout.RIGHT, 10, 10);
        panelBotonBuscar.add(botonBuscar);
        panelSuperior.add(panelBotonBuscar, BorderLayout.EAST);

        // Configuración de ActionListener para el botón "Buscar"
        configurarBotonBuscar();

        // Tabla de compras deshabilitada
        tablaCompras = GenerarComponentes.crearTabla(COLUMNAS);
        JScrollPane scrollTabla = GenerarComponentes.crearScrollPane(tablaCompras);

        // Panel inferior para los botones de exportación
        JPanel panelBotones = GenerarComponentes.crearPanelFlowLayout(FlowLayout.CENTER, 20, 10);

        botonExportarJSON = GenerarComponentes.crearBoton("Exportar en JSON");
        botonExportarCSV = GenerarComponentes.crearBoton("Exportar en CSV");
        botonExportarXML = GenerarComponentes.crearBoton("Exportar en XML");

        panelBotones.add(botonExportarJSON);
        panelBotones.add(botonExportarCSV);
        panelBotones.add(botonExportarXML);

        // Configuración de ActionListeners para los botones de exportación
        configurarBotonesExportacion();

        // Añadir componentes al panel principal
        add(panelSuperior, BorderLayout.NORTH);   // Panel superior con campos de búsqueda
        add(scrollTabla, BorderLayout.CENTER);    // Tabla de compras en el centro
        add(panelBotones, BorderLayout.SOUTH);    // Botones de exportación en la parte inferior

        actualizarTabla(); // Actualizar tabla inicialmente
    }

    private void configurarBotonBuscar() {
        botonBuscar.addActionListener(e -> {
            String proveedor = campoBusquedaProveedor.getText();
            String fecha = campoBusquedaFecha.getText();
            
            // Aquí puedes llamar al controlador para buscar según los filtros
            actualizarTabla(proveedor, fecha);
        });
    }

    private void configurarBotonesExportacion() {
        botonExportarJSON.addActionListener(e -> {
            String archivo = "compras.json";
            ArrayList<String[]> datos = Controlador.llenarDatosDB(
                    "COMPRAS", "PRODUCTOS",
                    "COMPRAS.ID_COMPRA, PRODUCTOS.NOMBRE, COMPRAS.FECHA, COMPRAS.PROVEEDOR, COMPRAS.CANTIDAD",
                    "PRODUCTOS.ID_PRODUCTO = COMPRAS.ID_PRODUCTO");
            Controlador.exportarAJSON(datos, COLUMNAS, archivo);
        });

        botonExportarCSV.addActionListener(e -> {
            String archivo = "compras.csv";
            ArrayList<String[]> datos = Controlador.llenarDatosDB(
                    "COMPRAS", "PRODUCTOS",
                    "COMPRAS.ID_COMPRA, PRODUCTOS.NOMBRE, COMPRAS.FECHA, COMPRAS.PROVEEDOR, COMPRAS.CANTIDAD",
                    "PRODUCTOS.ID_PRODUCTO = COMPRAS.ID_PRODUCTO");
            Controlador.exportarACSV(datos, COLUMNAS, archivo);
        });

        botonExportarXML.addActionListener(e -> {
            String archivo = "compras.xml";
            ArrayList<String[]> datos = Controlador.llenarDatosDB(
                    "COMPRAS", "PRODUCTOS",
                    "COMPRAS.ID_COMPRA, PRODUCTOS.NOMBRE, COMPRAS.FECHA, COMPRAS.PROVEEDOR, COMPRAS.CANTIDAD",
                    "PRODUCTOS.ID_PRODUCTO = COMPRAS.ID_PRODUCTO");
            Controlador.exportarAXML(datos, COLUMNAS, archivo);
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        Color colorInicio = new Color(255, 94, 98);
        Color colorFinal = new Color(255, 175, 123);
        int width = getWidth();
        int height = getHeight();
        GradientPaint gp = new GradientPaint(0, 0, colorInicio, 0, height, colorFinal);
        g2d.setPaint(gp);
        g2d.fillRect(0, 0, width, height);
    }

    public void actualizarTabla() {
        // Obtener datos de la base de datos sin filtros
        ArrayList<String[]> compras = Controlador.llenarDatosDB(
                "COMPRAS", "PRODUCTOS",
                "COMPRAS.ID_COMPRA, PRODUCTOS.NOMBRE, COMPRAS.FECHA, COMPRAS.PROVEEDOR, COMPRAS.CANTIDAD",
                "PRODUCTOS.ID_PRODUCTO = COMPRAS.ID_PRODUCTO");
        String[][] datos = new String[compras.size()][COLUMNAS.length];

        for (int i = 0; i < compras.size(); i++) {
            datos[i] = compras.get(i);
        }

        tablaCompras.setModel(new javax.swing.table.DefaultTableModel(datos, COLUMNAS));

        tablaCompras.getColumnModel().getColumn(0).setPreferredWidth(80);  // ID Compra
        tablaCompras.getColumnModel().getColumn(1).setPreferredWidth(200); // Producto
        tablaCompras.getColumnModel().getColumn(2).setPreferredWidth(150); // Fecha
        tablaCompras.getColumnModel().getColumn(3).setPreferredWidth(150); // Proveedor
        tablaCompras.getColumnModel().getColumn(4).setPreferredWidth(100); // Cantidad

        // Deshabilitar todas las columnas
        for (int i = 0; i < COLUMNAS.length; i++) {
            tablaCompras.getColumnModel().getColumn(i).setResizable(false);
        }
    }

    public void actualizarTabla(String proveedor, String fecha) {
        // Aquí se haría el filtro por proveedor y fecha
        if (proveedor.isEmpty() && fecha.isEmpty()) {
            actualizarTabla();
            return;
        }
        if (proveedor.isEmpty()) {
            proveedor = "%";
            
        }
        if (fecha.isEmpty()) {
            fecha = "%";
        }
        ArrayList<String[]> compras = Controlador.llenarDatosDB(
                "COMPRAS", "PRODUCTOS",
                "COMPRAS.ID_COMPRA, PRODUCTOS.NOMBRE, COMPRAS.FECHA, COMPRAS.PROVEEDOR, COMPRAS.CANTIDAD",
                "PRODUCTOS.ID_PRODUCTO = COMPRAS.ID_PRODUCTO AND COMPRAS.PROVEEDOR LIKE '%" + proveedor + "%' AND COMPRAS.FECHA LIKE '%" + fecha + "%'");
        String[][] datos = new String[compras.size()][COLUMNAS.length];

        for (int i = 0; i < compras.size(); i++) {
            datos[i] = compras.get(i);
        }

        tablaCompras.setModel(new javax.swing.table.DefaultTableModel(datos, COLUMNAS));
    }
}
